---
name: Discord dashboard bridge
description: Durable constraints for executing Discord hybrid commands from the embedded dashboard.
---

The dashboard executor must resolve commands from the same loaded Cog tree used by Discord, including nested hybrid groups, aliases, slash-style separators, and typed Optional Discord objects.

**Why:** A catalog can appear complete while execution fails if lookup uses a Cog-level `get_command`, or if dashboard strings are not normalized before resolving nested commands.

**How to apply:** Keep catalog generation and execution lookup on the same command tree; normalize `/group child`, `group/child`, and `group.child` consistently, and convert Member, Role, and Channel parameters before invoking the real callback.